// backend/controllers/reportController.js
const path = require('path');
const ExcelJS = require('exceljs');
const collections = require('../config/collectionConfig'); // Collection list
const getAssetModel = require('../models/assetModel'); // Dynamic model generator

// Helper function to escape special characters in regex
function escapeRegex(text) {
    return text.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // Escapes special characters
}

const generateReport = async (req, res) => {
    try {
        const { assetList } = req.body; // Array of assets with all necessary fields

        // Path to the Excel template
        const templatePath = path.join(__dirname, '../templates/CySecAssure_Template.xlsx');
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.readFile(templatePath);
        const worksheet = workbook.getWorksheet('Risk Assessment');
        if (!worksheet) {
            console.error("Worksheet 'Risk Assessment' not found in template");
            return res.status(500).json({ message: "Worksheet not found in template" });
        }

        let currentRow = 7;

        for (const assetData of assetList) {
            const { assetName, actionOwner, riskIdentificationDate, existingControls, additionalControls } = assetData;
            console.log(`Processing asset: ${assetName}`);
            console.log(`Selected Controls for ${assetName}:`, existingControls);
            console.log(`Additional Controls for ${assetName}:`, additionalControls);

            // Escape special characters and create a regex for case-insensitive matching
            const escapedAssetName = escapeRegex(assetName);
            const regex = new RegExp(`^${escapedAssetName}$`, 'i');

            let dbData = null;

            // Loop through collections to find the asset data
            for (const collectionName of collections) {
                const AssetModel = getAssetModel(collectionName);
                dbData = await AssetModel.findOne({ 'Asset Name': regex });
                if (dbData) {
                    console.log(`Found data in collection '${collectionName}' for asset: ${assetName}`);
                    break;
                }
            }

            if (!dbData) {
                console.warn(`No data found in any collection for asset: ${assetName}`);
            }

            // Determine Control Effectiveness based on the count of existing controls
            const controlCount = existingControls ? existingControls.length : 0;
            let controlEffectiveness;
            if (controlCount === 1) {
                controlEffectiveness = "Ineffective";
            } else if (controlCount === 2) {
                controlEffectiveness = "Moderate";
            } else if (controlCount >= 3) {
                controlEffectiveness = "Effective";
            } else {
                controlEffectiveness = "Data Not Found";
            }

            // Populate the Excel worksheet with fetched data, user-selected existing controls, and additional fields
            worksheet.getCell(`A${currentRow}`).value = dbData?.['Risk ID'] || 'Data Not Found';
            worksheet.getCell(`B${currentRow}`).value = dbData?.['Asset ID'] || 'Data Not Found';
            worksheet.getCell(`C${currentRow}`).value = assetName || 'Asset Not Found';
            worksheet.getCell(`D${currentRow}`).value = dbData?.['Impact on Confidentiality'] || 'Data Not Found';
            worksheet.getCell(`E${currentRow}`).value = dbData?.['Impact on Integrity'] || 'Data Not Found';
            worksheet.getCell(`F${currentRow}`).value = dbData?.['Impact on Availability'] || 'Data Not Found';

            worksheet.getCell(`H${currentRow}`).value = dbData?.['Threats'] || 'Data Not Found';
            worksheet.getCell(`I${currentRow}`).value = dbData?.['Vulnerabilities'] || 'Data Not Found';
            worksheet.getCell(`J${currentRow}`).value = dbData?.['Risks'] || 'Data Not Found';

            // Write selected controls to column K
            worksheet.getCell(`K${currentRow}`).value = existingControls && existingControls.length > 0 
                ? existingControls.join('\n') 
                : 'No Controls Selected';

            worksheet.getCell(`L${currentRow}`).value = controlEffectiveness; // Control Effectiveness based on count
            worksheet.getCell(`M${currentRow}`).value = dbData?.['Probability'] || 'Data Not Found';
            worksheet.getCell(`N${currentRow}`).value = dbData?.['Impact'] || 'Data Not Found';
            worksheet.getCell(`O${currentRow}`).value = dbData?.['Risk Value'] || 'Data Not Found';
            worksheet.getCell(`P${currentRow}`).value = dbData?.['Priority for Risk Treatment'] || 'Data Not Found';
            worksheet.getCell(`Q${currentRow}`).value = dbData?.['Risk Treatment Category'] || 'Data Not Found';

            // Write additional controls to column R
            worksheet.getCell(`R${currentRow}`).value = additionalControls && additionalControls.length > 0 
                ? additionalControls.join('\n') 
                : 'No Additional Controls';

            worksheet.getCell(`S${currentRow}`).value = dbData?.['Revised Probability'] || 'Data Not Found';
            worksheet.getCell(`T${currentRow}`).value = dbData?.['Revised Impact'] || 'Data Not Found';
            worksheet.getCell(`U${currentRow}`).value = dbData?.['Revised Risk Value'] || 'Data Not Found';

            // Populate user-provided fields for Action Owner and Risk Identification Date
            worksheet.getCell(`V${currentRow}`).value = actionOwner || 'Data Not Found';
            worksheet.getCell(`Y${currentRow}`).value = riskIdentificationDate || 'Data Not Found';
            worksheet.getCell(`W${currentRow}`).value = '10-15 Days from Risk Identification Date'; // Static data for W column

            currentRow++;
        }

        // Save the populated workbook to a new file in the reports directory
        const reportPath = path.join(__dirname, '../reports/Tara Healthcare Report.xlsx');
        await workbook.xlsx.writeFile(reportPath);

        console.log("Report generated successfully at:", reportPath);
        res.json({ message: 'Report generated successfully!', reportUrl: `/reports/Tara Healthcare Report.xlsx` });

    } catch (error) {
        console.error('Error generating report:', error);
        res.status(500).json({ message: 'Failed to generate report.' });
    }
};

module.exports = { generateReport };