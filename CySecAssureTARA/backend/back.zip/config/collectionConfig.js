// backend/config/collectionConfig.js
module.exports = [
    '1. Cloud Infrastructure and Compute Services',
    '2. Cloud Storage and Database Services',
    // Add more collections as needed
];

